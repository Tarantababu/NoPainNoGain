/* Wordstack service worker — offline shell + CDN cache.
   Bump CACHE version when index.html changes to force an update. */
const CACHE = 'wordstack-v2';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png'];
const CDN_HOSTS = [
  'cdn.tailwindcss.com',
  'cdn.jsdelivr.net',
  'fonts.googleapis.com',
  'fonts.gstatic.com'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Never intercept API traffic (OpenAI, Supabase) — network only.
  if (url.origin === location.origin) {
    // App shell: cache-first, refresh in background; navigations fall back to index.html.
    e.respondWith(
      caches.match(req, { ignoreSearch: true }).then(cached => {
        const fetched = fetch(req).then(res => {
          if (res.ok) caches.open(CACHE).then(c => c.put(req, res.clone()));
          return res;
        }).catch(() => cached || (req.mode === 'navigate' ? caches.match('./index.html') : undefined));
        return cached || fetched;
      })
    );
  } else if (CDN_HOSTS.includes(url.hostname)) {
    // CDN assets: stale-while-revalidate so the app boots offline.
    e.respondWith(
      caches.match(req).then(cached => {
        const fetched = fetch(req).then(res => {
          caches.open(CACHE).then(c => c.put(req, res.clone()));
          return res;
        }).catch(() => cached);
        return cached || fetched;
      })
    );
  }
  // everything else (api.openai.com, *.supabase.co): default network behaviour
});
